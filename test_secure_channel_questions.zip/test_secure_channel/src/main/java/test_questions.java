import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class test_questions {

    public class question_answer
    {
        public String question;

        public question_answer(String question, String answer) {
            this.question = question;
            this.answer = answer;
        }

        public String answer;


    }


    static List<String> questions1;
    static List<String> questions2;
    static List<String>  questions3;

    public static List<question_answer> getMyquestions_answers() {
        return myquestions_answers;
    }

    static List<question_answer>  myquestions_answers= new ArrayList<question_answer>();


    static Random rnd = new Random();

    public static void main(String[] args) {

        test_questions test = new test_questions();
        try {
            test.collect();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public void collect() throws Exception {
        for(int i=0;i<5;i++) {
            myquestions_answers.add(getQuestion(i));
        }

        System.out.println("YOUR CHOICES");

        for(int i=0;i<5;i++) {
            System.out.println("*************************************");
            System.out.println("Q:"+myquestions_answers.get(i).question);
            System.out.println("A:"+myquestions_answers.get(i).answer);
            System.out.println("*************************************");
        }

        //next we load that to the card



    }
    public test_questions()
    {
        try {
            questions1 =  Files.readAllLines(new File(test_questions.class.getResource("questions1").getFile()).toPath());
            questions2 =  Files.readAllLines(new File(test_questions.class.getResource("questions2").getFile()).toPath());
            questions3 =  Files.readAllLines(new File(test_questions.class.getResource("questions3").getFile()).toPath());




        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }





    }

    public static String generateQuestion(int i) throws Exception {
        int index=-1;

        switch(i) {

            case 1:
                index= rnd.nextInt(0, questions1.size());
                return questions1.get(index);


            case 2:
                index= rnd.nextInt(0, questions2.size());
                return questions2.get(index);


            case 3:
                index= rnd.nextInt(0, questions3.size());
                return questions3.get(index);


            default:
                throw new Exception("programm error");

        }


    }

    public question_answer getQuestion(int n) throws Exception {
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Q#"+n+"... choose (C/c) or generate ? (G/g) ");

        String choice = myObj.nextLine();  // Read user input

        //user wants to choose
        if(choice.equalsIgnoreCase("c"))
        {

            System.out.println("Q#"+n+"...pick up a question (<256 alpha numeric symbols [A-Z,a-z,0-9] and spaces  only - no interrogation mark or any other symbols)");
            String question = myObj.nextLine();  // Read user input

            Pattern p = Pattern.compile("[A-Za-z0-9 ]+");
            Matcher m = p.matcher(question);
            boolean b = m.matches();

            if(!b)
            {
                throw new Exception("wrong question (contains forbidden characters)");
            }

            System.out.println("Q#"+n+"...provide an answer to the question (<256 alpha numeric symbols [A-Z,a-z,0-9] and spaces  only - no interrogation mark or any other symbols)");
            String answer = myObj.nextLine();  // Read user input

            p = Pattern.compile("[A-Za-z0-9 ]+");
            m = p.matcher(answer);
            b = m.matches();

            if(!b)
            {
                throw new Exception("wrong answer (contains forbidden characters)");
            }

            return new question_answer(question.toUpperCase(),answer.toUpperCase());
        }
        //we will generate for user
        else if(choice.equalsIgnoreCase("g"))
        {

            while(true) {
                System.out.println("Q#" + n + "...generate 1) 'normal' secret questions 2) very secret questions 3) extremely secret questions:  1-2-3");
                int choice2 = myObj.nextInt(); // Read user input

                String question = generateQuestion(choice2);
                System.out.println(question + "\n ok? yes: Y/y or no: N/n ");
                myObj.reset();
                String choice3 = myObj.nextLine();
                choice3 = myObj.nextLine();

                if (choice3.equalsIgnoreCase("y")) {
                    System.out.println("Q#"+n+"...provide an answer to the question (<256 alpha numeric symbols [A-Z,a-z,0-9] and spaces  only - no interrogation mark or any other symbols)");
                    String answer = myObj.nextLine();  // Read user input

                    Pattern p = Pattern.compile("[A-Za-z0-9 ]+");
                    Matcher m = p.matcher(answer);
                    Boolean b = m.matches();

                    if(!b)
                    {
                        throw new Exception("wrong answer (contains forbidden characters)");
                    }

                    return new question_answer(question.toUpperCase(),answer.toUpperCase());
                }

            }




        }
        else
        {
            throw new Exception("Wrong input");
        }







        //use GUI later on...
/*
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {


                Questions q = new Questions();
                q.setVisible(true);


            }
        });

 */


    }


}
